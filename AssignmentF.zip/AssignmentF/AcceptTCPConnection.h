#ifndef _ACCEPT_TCP_CONNECTION_H_
#define _ACCEPT_TCP_CONNECTION_H_

extern int AcceptTCPConnection (int servSock);  /* Accept TCP connection request */

#endif
